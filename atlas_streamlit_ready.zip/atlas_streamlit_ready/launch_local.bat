@echo off
title Atlas V9 Dealer Intelligence
cd /d "%~dp0"
python -m streamlit run app.py --server.port 8511
pause
