# Atlas V9 — Dealer Intelligence Briefing

Atlas V9 is a Streamlit dashboard for brokerage/dealing risk analysis.

## What it does

- Uploads CRM reports: old Orders CSV/TXT, ClosedDeals XLSX, or OpenDeals XLSX
- Normalizes trade/report data into one structure
- Builds dealer KPI cards
- Detects short-duration behaviour, symbol concentration, A-book candidates, and high-risk accounts
- Produces Dealer Action Center, Retail Emotion Index, Early Warning Radar, anomaly/baseline comparison, and downloadable CSV outputs

## Streamlit Cloud deployment

When creating the Streamlit app, use:

- Repository: your GitHub repository
- Branch: `main`
- Main file path: `app.py`

## Local run

Install dependencies:

```bash
pip install -r requirements.txt
```

Run the app:

```bash
streamlit run app.py
```

or double-click `launch_local.bat` on Windows.

## Important safety note

Do not upload real employer CRM reports, client names, account numbers, or confidential broker data to a public demo. Use anonymized/sample data only.
